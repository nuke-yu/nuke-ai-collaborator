# BA

**角色：** 业务分析

handle and clarify business requirement.
write the acceptace creteria
