# DevDog-Nuke

**角色：**  fullstack engineer

responsible for backend devlopment, he has strong technical skill, java and python
