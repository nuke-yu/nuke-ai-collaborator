#!/usr/bin/env python3
"""Write the complete index.html for the match-3 game."""
import os

# HTML + CSS + HTML body + start of script
part1 = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>开心消消乐</title>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;background:#1a1a2e;min-height:100vh;display:flex;justify-content:center;align-items:center;padding:16px;touch-action:none;user-select:none;-webkit-user-select:none}
.game-container{background:#16213e;border-radius:20px;padding:20px;box-shadow:0 8px 32px rgba(0,0,0,.3);max-width:100%}
.game-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;padding:0 4px}
.game-title{font-size:18px;font-weight:700;color:#e94560;letter-spacing:1px}
.game-status{font-size:13px;color:#8e8e93;padding:4px 12px;background:#0f3460;border-radius:8px}
.board-wrapper{position:relative;border-radius:12px;overflow:hidden;background:#0f3460;touch-action:none}
#gameCanvas{display:block;width:100%;height:auto;touch-action:none;cursor:pointer}
.game-footer{display:flex;justify-content:center;margin-top:16px;gap:12px}
.btn{border:none;border-radius:10px;padding:10px 24px;font-size:14px;font-weight:600;cursor:pointer;transition:all .15s ease;background:#0f3460;color:#e94560;font-family:inherit}
.btn:hover{background:#1a4a7a}
.btn:active{transform:scale(.95)}
.btn-shuffle{background:#e94560;color:#fff}
.btn-shuffle:hover{background:#d63851}
@media(max-width:500px){.game-container{padding:12px;border-radius:14px}.game-title{font-size:15px}.game-status{font-size:11px;padding:3px 10px}.btn{padding:8px 18px;font-size:12px}}
</style>
</head>
<body>
<div class="game-container">
<div class="game-header"><span class="game-title">开心消消乐</span><span class="game-status" id="statusText">就绪</span></div>
<div class="board-wrapper"><canvas id="gameCanvas"></canvas></div>
<div class="game-footer"><button class="btn btn-shuffle" id="shuffleBtn">洗牌</button></div>
</div>
<script>
(function(){
'use strict';
var R=10,C=10,K=6;
var PAL=[{r:233,g:69,b:96},{r:255,g:190,b:11},{r:0,g:180,b:216},{r:72,g:199,b:142},{r:175,g:82,b:222},{r:255,g:138,b:76}];
var DIRS=[[-1,0],[1,0],[0,-1],[0,1]];
var T_SWAP=200,T_POP=250,T_FALL=200,T_SHUFFLE=400;
var cv=document.getElementById('gameCanvas');
var cx=cv.getContext('2d');
var st=document.getElementById('statusText');
var board=[],cs=0,sel=null,anim=false,fc=null;
var af=null,at=0,aty=null,ad=null,animCb=null;
var dragStart=null,dragMoved=false;
'''

# JS functions part 1: resize through processMatches
part2 = r'''
function resize(){
var p=cv.parentElement,mw=Math.min(p.clientWidth,500),dpr=window.devicePixelRatio||1;
cv.style.width=mw+'px';cv.style.height=mw+'px';
cv.width=mw*dpr;cv.height=mw*dpr;cs=mw/R;
cx.setTransform(dpr,0,0,dpr,0,0);
if(!anim)draw();
}
function rc(){return Math.floor(Math.random()*K);}
function mkB(){return Array.from({length:R},function(){return Array.from({length:C},function(){return rc();});});}
function ib(r,c){return r>=0&&r<R&&c>=0&&c<C;}
function sw(b,r1,c1,r2,c2){var t=b[r1][c1];b[r1][c1]=b[r2][c2];b[r2][c2]=t;}
function adj(r1,c1,r2,c2){return Math.abs(r1-r2)+Math.abs(c1-c2)===1;}
function clB(b){return b.map(function(r){return r.slice();});}
function findM(b){
var s=new Set();
for(var r=0;r<R;r++)for(var c=0;c<C;c++){
var cl=b[r][c];if(cl<0)continue;
var q=[{r:r,c:c}],v=new Set([r*C+c]),g=[{r:r,c:c}];
while(q.length){var u=q.shift();for(var di=0;di<4;di++){var dr=DIRS[di][0],dc=DIRS[di][1],nr=u.r+dr,nc=u.c+dc,k=nr*C+nc;if(ib(nr,nc)&&!v.has(k)&&b[nr][nc]===cl){v.add(k);q.push({r:nr,c:nc});g.push({r:nr,c:nc});}}}
if(g.length>=2)for(var gi=0;gi<g.length;gi++)s.add(g[gi].r*C+g[gi].c);
}
return s;
}
function hasM(b){
for(var r=0;r<R;r++)for(var c=0;c<C;c++)for(var di=0;di<4;di++){
var dr=DIRS[di][0],dc=DIRS[di][1],nr=r+dr,nc=c+dc;if(!ib(nr,nc))continue;
sw(b,r,c,nr,nc);var m=findM(b);sw(b,r,c,nr,nc);
if(m.size>0)return true;
}
return false;
}
function gravInfo(b){
var cols=[];
for(var c=0;c<C;c++){
var drops=[];var wr=R-1;
for(var r=R-1;r>=0;r--){
if(b[r][c]>=0){
if(r!==wr){drops.push({fr:r,to:wr,cl:b[r][c]});b[wr][c]=b[r][c];b[r][c]=-1;}
wr--;
}
}
var nc2=wr+1;
for(var r=wr;r>=0;r--){var cl=rc();drops.push({fr:r-nc2,to:r,cl:cl,isNew:true});b[r][c]=cl;}
if(drops.length>0)cols.push({c:c,drops:drops});
}
return cols;
}
function roundRect(ctx,x,y,w,h,r){
if(r>w/2)r=w/2;if(r>h/2)r=h/2;
ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);
ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);
ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.closePath();
}
function drawBoard(b,extras){
var sz=cv.width/(window.devicePixelRatio||1);
cx.clearRect(0,0,sz,sz);var gap=2,rad=cs*0.18;
var em={};if(extras)for(var ei=0;ei<extras.length;ei++)em[extras[ei].r*C+extras[ei].c]=extras[ei];
for(var r=0;r<R;r++)for(var c=0;c<C;c++){
var cl=b[r][c];if(cl<0)continue;
var e=em[r*C+c];
var x=c*cs+gap,y=r*cs+gap,w=cs-gap*2,s=1,a=1;
if(e){if(e.ox)x+=e.ox;if(e.oy)y+=e.oy;if(e.s!==undefined)s=e.s;if(e.a!==undefined)a=e.a;}
var dw=w*s,dh=w*s,dx=x+(w-dw)/2,dy=y+(w-dh)/2;
var p=PAL[cl];
cx.save();cx.globalAlpha=a;
cx.shadowColor='rgba(0,0,0,0.2)';cx.shadowBlur=4;cx.shadowOffsetY=2;
cx.beginPath();roundRect(cx,dx,dy,dw,dh,rad);
cx.fillStyle='rgb('+p.r+','+p.g+','+p.b+')';cx.fill();
cx.shadowColor='transparent';cx.shadowBlur=0;cx.shadowOffsetY=0;
var gr=cx.createRadialGradient(dx+dw*.3,dy+dw*.3,0,dx+dw*.3,dy+dw*.3,dw*.6);
gr.addColorStop(0,'rgba(255,255,255,0.3)');gr.addColorStop(1,'rgba(255,255,255,0)');
cx.fillStyle=gr;cx.beginPath();roundRect(cx,dx,dy,dw,dh,rad);cx.fill();
if(sel&&sel.r===r&&sel.c===c){
cx.strokeStyle='#fff';cx.lineWidth=3;
cx.shadowColor='rgba(255,255,255,0.5)';cx.shadowBlur=8;
cx.beginPath();roundRect(cx,dx,dy,dw,dh,rad);cx.stroke();
}
cx.restore();
}
}
function draw(){drawBoard(board);}
function animLoop(ts){
if(!af)return;
if(!at)at=ts;
var el=ts-at,p=Math.min(el/(ad.dur||300),1);
var ease=p<0.5?2*p*p:1-(-2*p+2)*(1-p)/2;
if(aty==='swap')animSwapTick(p,ease);
else if(aty==='pop')animPopTick(p,ease);
else if(aty==='fall')animFallTick(p,ease);
else if(aty==='shuffle')animShuffleTick(p,ease);
if(p>=1){animEnd();return;}
af=requestAnimationFrame(animLoop);
}
function animEnd(){
cancelAnimationFrame(af);af=null;at=0;aty=null;ad=null;anim=false;
if(typeof animCb==='function'){var cb=animCb;animCb=null;cb();}
}
function startSwapAnim(r1,c1,r2,c2,rev,cb){
anim=true;aty='swap';at=0;animCb=cb;
ad={r1:r1,c1:c1,r2:r2,c2:c2,rev:rev,dur:T_SWAP};
sw(board,r1,c1,r2,c2);
af=requestAnimationFrame(animLoop);
}
function animSwapTick(p,ease){
var d=ad;
var ox1=(d.c2-d.c1)*cs*ease,oy1=(d.r2-d.r1)*cs*ease;
var ox2=(d.c1-d.c2)*cs*ease,oy2=(d.r1-d.r2)*cs*ease;
var b2=clB(board);
b2[d.r1][d.c1]=-1;b2[d.r2][d.c2]=-1;
var extras=[{r:d.r1,c:d.c1,ox:ox1,oy:oy1,s:1,a:1},{r:d.r2,c:d.c2,ox:ox2,oy:oy2,s:1,a:1}];
drawBoard(b2,extras);
}
function startPopAnim(cells,cb){
anim=true;aty='pop';at=0;animCb=cb;
ad={cells:cells,dur:T_POP};
for(var i=0;i<cells.length;i++)board[cells[i].r][cells[i].c]=-1;
af=requestAnimationFrame(animLoop);
}
function animPopTick(p,ease){
var d=ad;var s=1-ease*0.8;var a=1-ease;
var extras=[];for(var i=0;i<d.cells.length;i++)extras.push({r:d.cells[i].r,c:d.cells[i].c,ox:0,oy:0,s:s,a:a});
drawBoard(board,extras);
}
function startFallAnim(cols,cb){
anim=true;aty='fall';at=0;animCb=cb;
ad={cols:cols,dur:T_FALL};
af=requestAnimationFrame(animLoop);
}
function animFallTick(p,ease){
var d=ad;var extras=[];
for(var ci=0;ci<d.cols.length;ci++){var col=d.cols[ci];for(var di=0;di<col.drops.length;di++){var drop=col.drops[di];var dist=drop.to-drop.fr;var curR=drop.fr+dist*ease;var oy=(curR-drop.to)*cs;extras.push({r:drop.to,c:col.c,ox:0,oy:oy,s:1,a:1});}}
drawBoard(board,extras);
}
function startShuffleAnim(oldB,newB,cb){
anim=true;aty='shuffle';at=0;animCb=cb;
ad={oldB:oldB,newB:newB,dur:T_SHUFFLE};
board=clB(oldB);
af=requestAnimationFrame(animLoop);
}
function animShuffleTick(p,ease){
var d=ad;var extras=[];var half=0.5;
if(p<=half){var t=p/half;var s=1-t;var a=1-t;for(var r=0;r<R;r++)for(var c=0;c<C;c++)extras.push({r:r,c:c,ox:0,oy:0,s:s,a:a});drawBoard(d.oldB,extras);}
else{var t=(p-half)/half;var s=t;var a=t;for(var r=0;r<R;r++)for(var c=0;c<C;c++)extras.push({r:r,c:c,ox:0,oy:0,s:s,a:a});drawBoard(d.newB,extras);}
if(p>=1)board=clB(d.newB);
}
function processMatches(cb){
var matches=findM(board);
if(matches.size===0){
if(!hasM(board)){shuffleBoard(cb);return;}
if(typeof cb==='function')cb();
return;
}
var cells=[];var keys=Array.from(matches);for(var i=0;i<keys.length;i++){var r=Math.floor(keys[i]/C),c=keys[i]%C;cells.push({r:r,c:c});}
st.textContent='消除中...';
startPopAnim(cells,function(){
var cols=gravInfo(board);
if(cols.length>0){st.textContent='掉落中...';startFallAnim(cols,function(){processMatches(cb);});}
else{processMatches(cb);}
});
}
'''

# JS functions part 3: shuffleBoard through init
part3 = r'''
function shuffleBoard(cb){
st.textContent='洗牌中...';var oldB=clB(board);var newB;
do{newB=mkB();}while(!hasM(newB));
startShuffleAnim(oldB,newB,function(){board=newB;sel=null;fc=null;st.textContent='就绪';draw();if(typeof cb==='function')cb();});
}
function trySwap(r1,c1,r2,c2){
if(anim)return;if(!adj(r1,c1,r2,c2))return;
sw(board,r1,c1,r2,c2);
var matches=findM(board);
if(matches.size===0){sw(board,r1,c1,r2,c2);startSwapAnim(r1,c1,r2,c2,true,function(){sel=null;fc=null;draw();});return;}
startSwapAnim(r1,c1,r2,c2,false,function(){sel=null;fc=null;processMatches(function(){st.textContent='就绪';});});
}
function getCellFromPoint(px,py){
var c=Math.floor(px/cs),r=Math.floor(py/cs);
if(ib(r,c))return{r:r,c:c};return null;
}
function getPointerPos(clientX,clientY){
var rect=cv.getBoundingClientRect();
var dpr=window.devicePixelRatio||1;
var x=(clientX-rect.left)*(cv.width/rect.width)/dpr;
var y=(clientY-rect.top)*(cv.height/rect.height)/dpr;
return{x:x,y:y};
}
function handleClick(r,c){
if(anim)return;
if(fc===null){fc={r:r,c:c};sel={r:r,c:c};draw();return;}
if(fc.r