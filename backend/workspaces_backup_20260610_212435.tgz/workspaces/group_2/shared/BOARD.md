# 任务看板 (BOARD.md)

(由系统基于真实数据库渲染，手动修改无效)

## Backlog
| ID | Title | Assignee | Status |
|---|---|---|---|
| DFT-4 | 界面布局与交互 | [-] | Backlog |
| DFT-3 | 异常处理与用户提示 | [-] | Backlog |
| DFT-2 | 小数与负数支持 | [-] | Backlog |
| DFT-1 | 计算器核心运算引擎 | [-] | Backlog |

## In Progress
| ID | Title | Assignee | Status |
|---|---|---|---|


## Done
| ID | Title | Assignee | Status |
|---|---|---|---|

