// ============================================================
// 计算器核心逻辑
// ============================================================

// ---- 状态 ----
let expression = '';       // 当前表达式字符串
let justCalculated = false; // 刚按过 =，下次输入数字时清空
let displayEl = document.getElementById('display');
let errorEl = document.getElementById('errorDisplay');

// ---- 工具函数 ----
function updateDisplay() {
  displayEl.textContent = expression || '0';
}

function clearError() {
  errorEl.textContent = '';
}

function showError(msg) {
  errorEl.textContent = msg;
}

// ---- 输入处理 ----
function inputValue(val) {
  clearError();

  if (justCalculated) {
    // 刚算完结果，如果输入数字或小数点，重新开始
    if (/[0-9.]/.test(val)) {
      expression = '';
    }
    justCalculated = false;
  }

  // 处理 ± 按钮
  if (val === 'negate') {
    // 尝试对当前输入的数字取反
    expression = toggleNegate(expression);
    updateDisplay();
    return;
  }

  expression += val;
  updateDisplay();
}

function toggleNegate(expr) {
  // 找到最后一个数字（从末尾往前找）
  const match = expr.match(/(\d+\.?\d*)$/);
  if (!match) return expr + '(-';

  const num = match[1];
  const idx = match.index;
  const before = expr.slice(0, idx);

  // 如果前面有负号，去掉；否则加负号
  if (before.endsWith('-')) {
    return before.slice(0, -1) + num;
  } else {
    return before + '-' + num;
  }
}

function inputParen() {
  clearError();

  if (justCalculated) {
    expression = '';
    justCalculated = false;
  }

  // 统计当前左右括号数
  const openCount = (expression.match(/\(/g) || []).length;
  const closeCount = (expression.match(/\)/g) || []).length;

  if (openCount > closeCount) {
    // 有未闭合的左括号，插入右括号
    expression += ')';
  } else {
    // 否则插入左括号
    // 如果表达式末尾是数字，自动加乘号
    if (/[\d.)]$/.test(expression)) {
      expression += '*(';
    } else {
      expression += '(';
    }
  }

  updateDisplay();
}

function inputOperator(op) {
  clearError();
  justCalculated = false;

  // 如果表达式为空且输入负号，允许以负号开头
  if (expression === '' && op === '-') {
    expression = '-';
    updateDisplay();
    return;
  }

  // 如果表达式为空，忽略运算符
  if (expression === '') return;

  // 如果末尾已经是运算符，替换它
  const lastChar = expression.slice(-1);
  if ('+-*/'.includes(lastChar)) {
    expression = expression.slice(0, -1) + op;
    updateDisplay();
    return;
  }

  // 如果末尾是小数点，不允许跟运算符
  if (lastChar === '.') return;

  expression += op;
  updateDisplay();
}

function inputPercent() {
  clearError();
  if (expression === '') return;

  // 尝试提取最后一个数字，除以100
  const match = expression.match(/(\d+\.?\d*)$/);
  if (match) {
    const num = parseFloat(match[1]);
    const result = (num / 100).toString();
    expression = expression.slice(0, match.index) + result;
    updateDisplay();
  }
}

function clearAll() {
  expression = '';
  justCalculated = false;
  clearError();
  updateDisplay();
}

function backspace() {
  if (justCalculated) {
    clearAll();
    return;
  }
  expression = expression.slice(0, -1);
  clearError();
  updateDisplay();
}

// ============================================================
// 计算引擎 — 中缀转后缀（Shunting-yard）+ 栈求值
// ============================================================

function tokenize(expr) {
  const tokens = [];
  let i = 0;
  const len = expr.length;

  while (i < len) {
    const ch = expr[i];

    // 跳过空格
    if (ch === ' ') {
      i++;
      continue;
    }

    // 数字或小数点
    if (/[0-9.]/.test(ch)) {
      let num = '';
      while (i < len && /[0-9.]/.test(expr[i])) {
        num += expr[i];
        i++;
      }
      // 检查是否有多余小数点
      if ((num.match(/\./g) || []).length > 1) {
        return { error: '数字格式错误' };
      }
      tokens.push({ type: 'number', value: num });
      continue;
    }

    // 运算符和括号
    if ('+-*/()'.includes(ch)) {
      // 处理一元负号：当负号在开头或前一个 token 是运算符/左括号时
      if (ch === '-') {
        const prev = tokens[tokens.length - 1];
        if (tokens.length === 0 || (prev && (prev.type === 'operator' || prev.value === '('))) {
          // 一元负号，附加到下一个数字
          tokens.push({ type: 'unary', value: '-' });
          i++;
          continue;
        }
      }

      tokens.push({ type: 'operator', value: ch });
      i++;
      continue;
    }

    // 非法字符
    return { error: `非法字符: "${ch}"` };
  }

  return { tokens };
}

function shuntingYard(tokens) {
  const output = [];
  const opStack = [];
  const precedence = { '+': 1, '-': 1, '*': 2, '/': 2 };
  let expectOperand = true; // 用于检测连续运算符

  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];

    if (tok.type === 'number') {
      output.push(tok);
      expectOperand = false;
    } else if (tok.type === 'unary') {
      // 一元负号，优先级最高
      opStack.push(tok);
      expectOperand = true;
    } else if (tok.type === 'operator') {
      if (tok.value === '(') {
        opStack.push(tok);
        expectOperand = true;
      } else if (tok.value === ')') {
        // 弹出直到左括号
        while (opStack.length > 0 && opStack[opStack.length - 1].value !== '(') {
          output.push(opStack.pop());
        }
        if (opStack.length === 0) {
          return { error: '括号不匹配：多余的右括号' };
        }
        opStack.pop(); // 移除左括号

        // 如果左括号前有一元负号，也弹出
        if (opStack.length > 0 && opStack[opStack.length - 1].type === 'unary') {
          output.push(opStack.pop());
        }

        expectOperand = false;
      } else {
        // 二元运算符
        if (expectOperand) {
          return { error: '表达式格式错误：连续运算符' };
        }

        while (
          opStack.length > 0 &&
          opStack[opStack.length - 1].value !== '(' &&
          precedence[opStack[opStack.length - 1].value] >= precedence[tok.value]
        ) {
          output.push(opStack.pop());
        }

        // 如果栈顶是 unary，也要弹出（unary 优先级高于所有二元）
        if (opStack.length > 0 && opStack[opStack.length - 1].type === 'unary') {
          output.push(opStack.pop());
        }
        opStack.push(tok);
        expectOperand = true;
      }
    }
  }

  // 检查括号是否匹配
  for (const op of opStack) {
    if (op.value === '(') {
      return { error: '括号不匹配：缺少右括号' };
    }
  }

  // 弹出剩余运算符
  while (opStack.length > 0) {
    output.push(opStack.pop());
  }

  return { output };
}

function evaluateRPN(tokens) {
  const stack = [];

  for (const tok of tokens) {
    if (tok.type === 'number') {
      stack.push(parseFloat(tok.value));
    } else if (tok.type === 'unary') {
      const a = stack.pop();
      if (a === undefined) return { error: '表达式格式错误' };
      stack.push(-a);
    } else if (tok.type === 'operator') {
      const b = stack.pop();
      const a = stack.pop();
      if (a === undefined || b === undefined) {
        return { error: '表达式格式错误' };
      }

      let result;
      switch (tok.value) {
        case '+': result = a + b; break;
        case '-': result = a - b; break;
        case '*': result = a * b; break;
        case '/':
          if (b === 0) return { error: '除数不能为 0' };
          result = a / b;
          break;
        default:
          return { error: `未知运算符: ${tok.value}` };
      }

      // 处理浮点数精度（保留10位小数，去掉尾随0）
      result = parseFloat(result.toPrecision(12));
      stack.push(result);
    }
  }

  if (stack.length !== 1) {
    return { error: '表达式格式错误' };
  }

  return { result: stack[0] };
}

function calculate(expr) {
  // 空表达式
  if (!expr || expr.trim() === '') {
    return { error: '' };
  }

  // 只包含运算符或括号
  if (/^[+\-*/()\s]+$/.test(expr)) {
    return { error: '表达式不完整' };
  }

  // 词法分析
  const tokenResult = tokenize(expr);
  if (tokenResult.error) {
    return tokenResult;
  }

  // 中缀转后缀
  const shuntingResult = shuntingYard(tokenResult.tokens);
  if (shuntingResult.error) {
    return shuntingResult;
  }

  // 计算后缀表达式
  const evalResult = evaluateRPN(shuntingResult.output);
  return evalResult;
}

// ============================================================
// 执行计算（按 = 时调用）
// ============================================================

function evaluate() {
  clearError();

  if (!expression || expression.trim() === '') {
    return;
  }

  const result = calculate(expression);

  if (result.error) {
    showError(result.error);
    return;
  }

  // 显示结果
  const displayResult = result.result.toString();
  expression = displayResult;
  justCalculated = true;
  updateDisplay();
}

// ============================================================
// 按钮事件绑定
// ============================================================

document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('click', () => {
    // 数字按钮
    if (btn.dataset.value !== undefined) {
      inputValue(btn.dataset.value);
      return;
    }

    // 动作按钮
    const action = btn.dataset.action;
    switch (action) {
      case 'clear':
        clearAll();
        break;
      case 'paren':
        inputParen();
        break;
      case 'percent':
        inputPercent();
        break;
      case 'negate':
        inputValue('negate');
        break;
      case 'equals':
        evaluate();
        break;
      case 'add':
        inputOperator('+');
        break;
      case 'subtract':
        inputOperator('-');
        break;
      case 'multiply':
        inputOperator('*');
        break;
      case 'divide':
        inputOperator('/');
        break;
    }
  });
});

// ---- 键盘支持 ----
document.addEventListener('keydown', (e) => {
  const key = e.key;

  if (/^[0-9.]$/.test(key)) {
    e.preventDefault();
    inputValue(key);
    return;
  }

  switch (key) {
    case '+': e.preventDefault(); inputOperator('+'); break;
    case '-': e.preventDefault(); inputOperator('-'); break;
    case '*': e.preventDefault(); inputOperator('*'); break;
    case '/': e.preventDefault(); inputOperator('/'); break;
    case 'Enter':
    case '=':
      e.preventDefault();
      evaluate();
      break;
    case 'Backspace':
      e.preventDefault();
      backspace();
      break;
    case 'Escape':
    case 'c':
    case 'C':
      e.preventDefault();
      clearAll();
      break;
    case '(':
    case ')':
      e.preventDefault();
      inputParen();
      break;
    case '%':
      e.preventDefault();
      inputPercent();
      break;
  }
});

// ============================================================
// 深色模式切换
// ============================================================

const themeToggle = document.getElementById('themeToggle');

// 检测系统偏好
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
const savedTheme = localStorage.getItem('calculator-theme');

if (savedTheme) {
  document.documentElement.setAttribute('data-theme', savedTheme);
  themeToggle.textContent = savedTheme === 'dark' ? '☀️' : '🌙';
} else if (prefersDark) {
  document.documentElement.setAttribute('data-theme', 'dark');
  themeToggle.textContent = '☀️';
}

themeToggle.addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  themeToggle.textContent = next === 'dark' ? '☀️' : '🌙';
  localStorage.setItem('calculator-theme', next);
});

// 初始化显示
updateDisplay();
