// 从 script.js 提取计算引擎做单元测试
// 模拟浏览器环境
// 更完整的 mock
const mockElement = {
  textContent: '',
  addEventListener: () => {},
  setAttribute: () => {},
  getAttribute: () => null,
  style: {}
};

global.document = {
  getElementById: () => mockElement,
  querySelectorAll: () => [],
  addEventListener: () => {},
  documentElement: { setAttribute: () => {}, getAttribute: () => null }
};
global.localStorage = { getItem: () => null, setItem: () => {} };
global.window = { matchMedia: () => ({ matches: false }) };

// 加载 script.js
const fs = require('fs');
const code = fs.readFileSync('script.js', 'utf-8');
eval(code);

// 测试用
function test(desc, fn) {
  try {
    fn();
    console.log(`✅ ${desc}`);
  } catch (e) {
    console.log(`❌ ${desc}: ${e.message}`);
  }
}

function assertEq(actual, expected, msg) {
  if (actual !== expected) {
    // 尝试数值比较（浮点数容忍）
    if (typeof actual === 'number' && typeof expected === 'number') {
      if (Math.abs(actual - expected) < 1e-10) return;
    }
    throw new Error(`${msg || ''} 期望 ${expected}，实际 ${actual}`);
  }
}

function assert(condition, msg) {
  if (!condition) throw new Error(msg || '断言失败');
}

// ---- 测试 ----
console.log('=== 基本运算 ===');
test('1+2=3', () => {
  const r = calculate('1+2');
  assertEq(r.result, 3);
});
test('10-4=6', () => {
  const r = calculate('10-4');
  assertEq(r.result, 6);
});
test('3*5=15', () => {
  const r = calculate('3*5');
  assertEq(r.result, 15);
});
test('20/4=5', () => {
  const r = calculate('20/4');
  assertEq(r.result, 5);
});

console.log('\n=== 小数运算 ===');
test('3.14+2.86=6', () => {
  const r = calculate('3.14+2.86');
  assertEq(r.result, 6);
});

console.log('\n=== 负数运算 ===');
test('-5+3=-2', () => {
  const r = calculate('-5+3');
  assertEq(r.result, -2);
});
test('(-2)*4=-8', () => {
  const r = calculate('(-2)*4');
  assertEq(r.result, -8);
});
test('-(3+2)=-5', () => {
  const r = calculate('-(3+2)');
  assertEq(r.result, -5);
});

console.log('\n=== 括号运算 ===');
test('(1+2)*3=9', () => {
  const r = calculate('(1+2)*3');
  assertEq(r.result, 9);
});
test('2*(3+4*(5-1))=38', () => {
  const r = calculate('2*(3+4*(5-1))');
  assertEq(r.result, 38);
});

console.log('\n=== 混合运算（优先级） ===');
test('2+3*4=14', () => {
  const r = calculate('2+3*4');
  assertEq(r.result, 14);
});
test('2*3+4=10', () => {
  const r = calculate('2*3+4');
  assertEq(r.result, 10);
});
test('10-2*3+4/2=6', () => {
  const r = calculate('10-2*3+4/2');
  assertEq(r.result, 6);
});

console.log('\n=== 异常处理 ===');
test('除零报错', () => {
  const r = calculate('1/0');
  assertEq(r.error, '除数不能为 0');
});
test('括号不匹配-缺右括号', () => {
  const r = calculate('(1+2');
  assertEq(r.error, '括号不匹配：缺少右括号');
});
test('括号不匹配-多余右括号', () => {
  const r = calculate('1+2)');
  assertEq(r.error, '括号不匹配：多余的右括号');
});
test('连续运算符报错', () => {
  const r = calculate('1++2');
  assert(r.error && r.error.includes('格式错误'));
});
test('非法字符报错', () => {
  const r = calculate('1+@2');
  assert(r.error && r.error.includes('非法字符'));
});

console.log('\n=== 边界情况 ===');
test('空表达式', () => {
  const r = calculate('');
  assertEq(r.error, '');
});
test('单个数字', () => {
  const r = calculate('42');
  assertEq(r.result, 42);
});
test('负数开头', () => {
  const r = calculate('-3.5');
  assertEq(r.result, -3.5);
});

console.log('\n🎉 全部测试完成！');
