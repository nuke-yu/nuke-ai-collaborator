# 任务看板 (BOARD.md)

(由系统基于真实数据库渲染，手动修改无效)

## Backlog
| ID | Title | Assignee | Status |
|---|---|---|---|
| DFT-4 | DFT-1.3 键盘输入支持 | [-] | Backlog |
| DFT-3 | DFT-1.2 UI界面（计算器显示+按钮布局+交互逻辑） | [-] | Backlog |
| DFT-2 | DFT-1.1 计算引擎（四则运算+括号+优先级+精度） | [-] | Backlog |
| DFT-1 | 基础计算器 - 加减乘除四则运算 | [-] | Backlog |

## In Progress
| ID | Title | Assignee | Status |
|---|---|---|---|


## Done
| ID | Title | Assignee | Status |
|---|---|---|---|

