# SuperBot · 行事原则

Strict and rigorous
